package com.imooc.miaoshaproject.controller.viewobject;

/**
 * Created by hzllb on 2018/11/24.
 */
public class ZuulException extends RuntimeException {
}
